import tensorflow as tf
import numpy as np
from tensorflow.python.ops.rnn_cell import MultiRNNCell, LSTMCell, GRUCell, DropoutWrapper, ResidualWrapper
from tensorflow.contrib.layers import xavier_initializer, l2_regularizer

class Model(object):
	def __init__(self, config):
		self.words = tf.placeholder(tf.int32, shape=[None, None], name='words') # [batch, seq_len]
		self.y_train = tf.placeholder(tf.float32, shape=[None, 6], name='y_train') # [batch, num_classes]
		self.seq_len = tf.placeholder(tf.int32, shape=[None], name='seq_len') # [batch]
		self.keep_prob = tf.placeholder(tf.float32, name='keep_prob') # [drop_out rate]

		self.vocab_size = config['vocab_size']
		self.embedding_size = config['embedding_size']
		self.num_units = config['num_units']
		self.learning_rate = config['learning_rate']
		self.num_layers = config['num_layers']
		self.attention_size = config['attention_size']
		self.num_classes = config['num_classes']
		self.num_outputs = config['num_outputs']

		with tf.variable_scope('embeddings'):
			self.word_embeddings = tf.get_variable(name='embeddings',
				                                   shape=[self.vocab_size, self.embedding_size],
				                                   dtype=tf.float32,
				                                   initializer=xavier_initializer(),
				                                   trainable=True)

			self.word_emb = tf.nn.embedding_lookup(self.word_embeddings, self.words, name='word_emb') # [batch, seq_len, embedding_size]

		with tf.variable_scope('bi_directional_rnn'):
			def rnn_cell():
				cell = GRUCell(self.num_units, kernel_initializer=xavier_initializer())
				cell = DropoutWrapper(cell, output_keep_prob=self.keep_prob)
				return cell

			cell_fw = MultiRNNCell([rnn_cell() for _ in range(self.num_layers)])
			cell_bw = MultiRNNCell([rnn_cell() for _ in range(self.num_layers)])

			rnn_outputs, _ = tf.nn.bidirectional_dynamic_rnn(cell_fw, cell_bw, self.word_emb,
				                                  dtype=tf.float32, sequence_length=self.seq_len)

			rnn_outputs = tf.concat(rnn_outputs, axis=-1)
			rnn_outputs = tf.layers.dropout(rnn_outputs, self.keep_prob) # [batch, seq_len, 2*num_units]

		with tf.variable_scope('conv2d'):
			outputs = []
			for filter_width in [3, 5]:
				output = tf.layers.conv2d(tf.expand_dims(rnn_outputs, -1), self.num_outputs,
					                     kernel_size=(1, filter_width),
					                     kernel_initializer=xavier_initializer())
				output = tf.reduce_max(tf.nn.relu(output), axis=2)
				outputs.append(output)

			outputs = tf.concat(outputs, -1) # [batch, seq_len, 2 * num_outputs]

		scored = tf.squeeze(tf.layers.dense(outputs, 1), -1) # [batch, seq_len]
		scored = tf.nn.softmax(scored, -1) # [batch, seq_len]

		outputs = outputs * tf.expand_dims(scored, -1) # [batch_size, seq_len, 2 * num_output]
		outputs = tf.reduce_sum(outputs, 1) # [batch_size, 2 * num_output]
		outputs = tf.layers.dense(outputs, 128, activation=tf.nn.relu)

		self.logits = tf.layers.dense(outputs, units=self.num_classes)
		self.cost = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=self.logits,
			                                                labels=self.y_train))
		self.global_step = tf.Variable(0, trainable=False)

		def clip_grads(loss):
			variables = tf.trainable_variables()
			grads = tf.gradients(loss, variables)
			clipped_grads, _ = tf.clip_by_global_norm(grads, 5)
			return zip(clipped_grads, variables)

		self.optimizer = tf.train.AdamOptimizer(self.learning_rate).apply_gradients(clip_grads(self.cost), self.global_step)
		self.prediction = tf.nn.sigmoid(self.logits)
		self.accuracy = tf.reduce_mean(tf.cast(tf.equal(tf.round(self.prediction), self.y_train), tf.float32))