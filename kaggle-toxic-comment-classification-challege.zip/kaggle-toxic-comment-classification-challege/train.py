from preprocessing import *
from model import *
import pandas as pd

config = {
	'TRAINPATH': 'data/train.csv',
	'TESTPATH': 'data/test.csv',
	'batch_size': 300,
}

preprocessing = Preprocessing(config)

config['vocab_size'] = len(preprocessing.word_lst)
config['embedding_size'] = 5
config['num_units'] = 5
config['learning_rate'] = 0.005
config['num_layers'] = 1
config['attention_size'] = 5
config['num_classes'] = 6
config['num_outputs'] = 5

model = Model(config)

saver = tf.train.Saver()

best_accuracy = -10

with tf.Session() as sess:
	sess.run(tf.global_variables_initializer())
	# saver.restore(sess, 'model/model_0.98160297.ckpt')
	tf.get_default_graph()
	# feed_dict = [{model.words: preprocessing.x_test_batch[i], model.seq_len: preprocessing.seq_len_test_batch[i],
	#              model.keep_prob: 1.0} for i in range(np.shape(preprocessing.x_test_batch)[0])]

	# predict = []
	# print(np.shape(preprocessing.x_test_batch)[0])
	# print(np.shape(preprocessing.x_test_batch[-1]))
	# for i in range(np.shape(preprocessing.x_test_batch)[0]-1):
	#     pred = sess.run(model.prediction, feed_dict=feed_dict[i])
	#     predict.append(pred)
	    
	# predict.append(np.zeros((164, 6)))

	# df = pd.DataFrame()
	# for i in range(len(predict)):
	# 	df = df.append(pd.DataFrame(predict[i]))

	# submission = pd.read_csv('data/sample_submission.csv')
	# submission[["toxic", "severe_toxic", "obscene", "threat", "insult", "identity_hate"]] = np.array(df)
	# submission.to_csv('submission.csv', index=False)
	for i in range(30):
		total_cost = 0
		for k in range(np.shape(preprocessing.x_train_batch)[0]):
			batch_words = preprocessing.x_train_batch[k]
			batch_y = preprocessing.y_train_batch[k]
			batch_seq_len = preprocessing.seq_len_train_batch[k]

			feed_dict = {model.words: batch_words, model.y_train: batch_y,
			             model.seq_len: batch_seq_len, model.keep_prob: 0.5}

			step, loss, _ = sess.run([model.global_step, model.cost, model.optimizer],
				                     feed_dict=feed_dict)

			if step % 50 == 0 or step == 1:
				print("epoch %d, step %d, loss %f" % (i + 1, step, loss))

			total_cost += loss
		total_cost /= np.shape(preprocessing.x_train_batch)[0]
		print("epoch %d, avg loss %f" % (i + 1, total_cost))
		feed_dict = [{model.words: preprocessing.x_dev_batch[i], model.y_train: preprocessing.y_dev_batch[i],
		             model.seq_len: preprocessing.seq_len_dev_batch[i],
		             model.keep_prob: 1.0} for i in range(np.shape(preprocessing.x_dev_batch)[0])]
		accuracy = [sess.run(model.accuracy, feed_dict=feed_dict[i]) for i in range(np.shape(preprocessing.x_dev_batch)[0])]
		accuracy = np.mean(accuracy)
		print(accuracy)
		if accuracy >= best_accuracy:
			best_accuracy = accuracy
			saver.save(sess, 'model/model_' + str(best_accuracy) + '.ckpt')
