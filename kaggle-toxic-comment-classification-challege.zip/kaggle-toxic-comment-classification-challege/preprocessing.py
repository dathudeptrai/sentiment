import pandas as pd
import numpy as np
import re
import csv
import nltk
import gc
from keras.preprocessing import text, sequence
from sklearn.model_selection import train_test_split
from collections import Counter
import json

class Preprocessing(object):
	def __init__(self, config):
		self.df_train = pd.read_csv(config['TRAINPATH'])
		self.df_test = pd.read_csv(config['TESTPATH'])
		self.train_input = self.df_train['comment_text']
		self.test_input = self.df_test['comment_text']
		# print('Procecssing data ...')
		# self.x_train = self.train_input.apply(self.__clean)
		self.y_train = self.df_train[['toxic', 'severe_toxic', 'obscene', 'threat', 'insult', 'identity_hate']]
		self.x_test = self.test_input.apply(self.__clean)
		#self.x_train = self.x_train.fillna('fillna')
		self.x_test = self.x_test.fillna('fillna')
		print('Buid word, charactor vocabulary ...')
		self.__buid_word_vocabulary()
		print('Load sequence to index ...')
		# self.x_train, self.seq_len_train = self.__sequence2idx(self.x_train)
		# self.x_test, self.seq_len_test = self.__sequence2idx(self.x_test)
		# np.save('train-test-idx/x_train.npy', self.x_train)
		# np.save('train-test-idx/x_test.npy', self.x_test)
		# np.save('train-test-idx/seq_len_train.npy', self.seq_len_train)
		# np.save('train-test-idx/seq_len_test.npy', self.seq_len_test)

		self.x_train = np.load('train-test-idx/x_train.npy')
		self.x_test = np.load('train-test-idx/x_test.npy')
		self.seq_len_train = np.load('train-test-idx/seq_len_train.npy')
		self.seq_len_test = np.load('train-test-idx/seq_len_test.npy')
		self.y_train = list(zip(self.y_train['toxic'], self.y_train['severe_toxic'], self.y_train['obscene'],
			               self.y_train['threat'], self.y_train['insult'], self.y_train['identity_hate']))

		print('Processing batch size ...')
		self.x_test_batch, self.seq_len_test_batch = self.__batch_iter_test(config['batch_size'])
		self.x_train_batch, self.y_train_batch, self.seq_len_train_batch = self.__batch_iter(config['batch_size'])
		self.x_train_batch, self.x_dev_batch, self.y_train_batch, self.y_dev_batch, self.seq_len_train_batch, self.seq_len_dev_batch = \
		           train_test_split(self.x_train_batch, self.y_train_batch, self.seq_len_train_batch, test_size=0.4, random_state=42)

	def __clean(self, string):
	    string = re.sub(r'\n', ' ', string)
	    string = re.sub(r'\t', ' ', string)
	    string = re.sub("[^A-Za-z\(\)\,\.\?\'\!]", " ", string)
	    string = re.sub("\'m", ' am ', string)
	    string = re.sub("\'s", ' is ', string)
	    string = re.sub("can\'t", 'cannot ', string)
	    string = re.sub("n\'t", ' not ', string)
	    string = re.sub("\'ve", ' have ', string)
	    string = re.sub("\'re", ' are ', string)
	    string = re.sub("\'d", " would ", string)
	    string = re.sub("\'ll", " will ", string)
	    string = re.sub("\,", " , ", string)
	    string = re.sub("\'", " ' ", string)
	    string = re.sub("\.", " . ", string)
	    string = re.sub("\!", " ! ", string)
	    string = re.sub(r"\(", " ( ", string)
	    string = re.sub(r"\)", " ) ", string)
	    string = re.sub(r"\?", " ? ", string)
	    string = re.sub(r'\s{2,}', ' ', string.lower())
	    string = re.sub(r'\d+', '', string)
	    return string.lower()

	def __buid_word_vocabulary(self):
	 	self.word_lst = {}
	 	self.charactor_lst = {}
	 	# self.word_lst['PAD'] = 0
	 	# self.word_lst['UNK'] = 1
	 	# self.charactor_lst['PAD'] = 0
	 	# self.charactor_lst['UNK'] = 1
	 	# count = 2
	 	# count_char = 2
	 	# for line in self.x_train:
	 	# 	for word in line.split():
	 	# 		if word not in self.word_lst:
	 	# 			self.word_lst[word] = count
	 	# 			count += 1
	 	# 		for charactor in word:
	 	# 			if charactor not in self.charactor_lst:
	 	# 				self.charactor_lst[charactor] = count_char
	 	# 				count_char += 1

	 	# with open('vocabulary/word.json', 'w') as outfile:
	 	# 	json.dump(self.word_lst, outfile)

	 	# with open('vocabulary/char.json', 'w') as outfile:
	 	# 	json.dump(self.charactor_lst, outfile)
	 	with open('vocabulary/word.json', 'r') as infile:
	 		self.word_lst = json.load(infile)

	 	with open('vocabulary/char.json', 'r') as infile:
	 		self.char_lst = json.load(infile)

	def __sequence2idx(self, data):
		seq_len = []
		sequences = []
		for i in range(len(data)):
			temp = []
			sequence = data[i]
			seq_len.append(len(sequence.split()))
			for word in sequence.split():
				if word in self.word_lst:
					temp.append(self.word_lst[word])
				else:
					temp.append(1)
			sequences.append(temp)

		return sequences, seq_len

	def __batch_iter(self, batch_size):
		max_sentences_length = max(list(map(lambda x: len(x), self.x_train)))
		max_sentences_length = 200

		self.x_train = sequence.pad_sequences(self.x_train, maxlen=max_sentences_length, padding='post')

		num_batch = np.shape(self.x_train)[0] // batch_size
		remining = np.shape(self.x_train)[0] - num_batch * batch_size

		sentences_batch = [self.x_train[i:i+batch_size] for i in range(0, np.shape(self.x_train)[0] - remining, batch_size)]
		sentences_batch.append(self.x_train[-remining:])

		y_batch = [self.y_train[i:i+batch_size] for i in range(0, np.shape(self.x_train)[0] - remining, batch_size)]
		y_batch.append(self.y_train[-remining:])

		seq_len_batch = [self.seq_len_train[i:i+batch_size] for i in range(0, np.shape(self.x_train)[0] - remining, batch_size)]
		seq_len_batch.append(self.seq_len_train[-remining:])

		return sentences_batch, y_batch, seq_len_batch		


	def __batch_iter_test(self, batch_size):
		max_sentences_length = max(list(map(lambda x: len(x), self.x_train)))
		max_sentences_length = 200

		self.x_test = sequence.pad_sequences(self.x_test, maxlen=max_sentences_length, padding='post')

		num_batch = np.shape(self.x_train)[0] // batch_size
		remining = np.shape(self.x_train)[0] - num_batch * batch_size

		sentences_batch = [self.x_test[i:i+batch_size] for i in range(0, np.shape(self.x_test)[0] - remining, batch_size)]
		sentences_batch.append(self.x_test[-remining:])

		seq_len_batch = [self.seq_len_test[i:i+batch_size] for i in range(0, np.shape(self.x_train)[0] - remining, batch_size)]
		seq_len_batch.append(self.seq_len_test[-remining:])

		return sentences_batch, seq_len_batch		

